// V2 backend contract (Node/Express pseudocode).
// Deploy this on a server with a running SWGOH Comlink instance.
//
// GET /api/roster/:allyCode
//
// const { SwgohComlink } = require("...");
// const comlink = new SwgohComlink({ url: process.env.SWGOH_COMLINK_URL });
// const player = await comlink.get_player({ allycode: Number(req.params.allyCode) });
// const roster = (player.rosterUnit || []).map(unit => ({
//   baseId: unit.defId,
//   name: localize(unit.defId),
//   rarity: unit.rarity,
//   level: unit.level,
//   gear: unit.gear,
//   relic: unit.relic?.currentTier ?? 0,
//   skills: unit.skills || [],
//   mods: unit.equipment || []
// }));
// res.json({ name: player.name, roster });
//
// Keep Comlink behind the backend; never expose private server credentials in the browser.
