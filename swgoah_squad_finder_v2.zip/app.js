const teams=[
{name:"Empire Control",leader:"Emperor Palpatine",chars:["Emperor Palpatine","Darth Vader","Mara Jade","Grand Admiral Thrawn","Royal Guard"],score:94,modes:["GAC","TW"],why:"Control-heavy Empire team with strong turn-meter manipulation."},
{name:"Jedi Revan",leader:"Jedi Knight Revan",chars:["Jedi Knight Revan","Bastila Shan","Jolee Bindo","Grand Master Yoda","General Kenobi"],score:91,modes:["GAC","PvE"],why:"Reliable Jedi core with healing, assists and strong leadership."},
{name:"Empire Core",leader:"Emperor Palpatine",chars:["Emperor Palpatine","Darth Vader","Grand Admiral Thrawn","Mara Jade","Stormtrooper"],score:88,modes:["GAC","PvE"],why:"Flexible Empire option when the full control team is unavailable."},
{name:"Phoenix",leader:"Hera Syndulla",chars:["Hera Syndulla","Captain Rex","Kanan Jarrus","Zeb Orrelios","Chopper"],score:86,modes:["PvE","TW"],why:"Useful progression team with strong Phoenix synergy."}
];
let roster=[];
const views=[...document.querySelectorAll(".view")];
function show(id){views.forEach(v=>v.classList.toggle("active",v.id===id));document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===id))}
document.querySelectorAll(".nav").forEach(n=>n.onclick=()=>show(n.dataset.view));
document.getElementById("goImport").onclick=()=>show("import");
function render(){
 const cards=teams.filter(t=>document.getElementById("mode").value==="all"||t.modes.includes(document.getElementById("mode").value)).map(t=>{
  const have=t.chars.filter(c=>roster.includes(c.toLowerCase())), pct=Math.round(have.length/5*100), missing=t.chars.filter(c=>!roster.includes(c.toLowerCase()));
  return `<article class="card"><div class="top"><div><div class="eyebrow">${t.leader}</div><h3>${t.name}</h3></div><div class="score">${pct}%</div></div><div class="bar"><i style="width:${pct}%"></i></div><div class="chips">${t.chars.map(c=>`<span class="chip">${c}</span>`).join("")}</div><p class="muted">${missing.length?`Missing: ${missing.join(", ")}`:"Complete ✓"}</p><p class="muted">${t.why}</p></article>`;
 }).join("");
 document.getElementById("cards").innerHTML=cards||"<div class='panel'>No teams for this filter.</div>";
 document.getElementById("dash").innerHTML=`<div class="statrow"><div class="stat"><b>${roster.length}</b><span>Characters loaded</span></div><div class="stat"><b>${teams.filter(t=>t.chars.every(c=>roster.includes(c.toLowerCase()))).length}</b><span>Complete squads</span></div><div class="stat"><b>${teams.filter(t=>t.chars.filter(c=>roster.includes(c.toLowerCase())).length>=4).length}</b><span>Near-complete</span></div></div>`;
}
function setDemo(){
 roster=["darth vader","emperor palpatine","mara jade","grand admiral thrawn","royal guard","jedi knight revan","bastila shan","grand master yoda","general kenobi","stormtrooper"];
 document.getElementById("status").textContent="Demo roster loaded. The same normalized roster format will be used by the real API.";
 show("dashboard");render();
}
document.getElementById("demoBtn").onclick=setDemo;
document.getElementById("importBtn").onclick=async()=>{
 const code=document.getElementById("ally").value.replace(/\D/g,"");
 const status=document.getElementById("status");
 if(code.length!==9){status.textContent="Please enter a 9-digit Ally Code.";return}
 status.textContent="Connecting to /api/roster/"+code+" …";
 try{
  const r=await fetch("/api/roster/"+code);
  if(!r.ok) throw new Error("Backend not configured or roster unavailable.");
  const data=await r.json();
  roster=(data.roster||[]).map(x=>(x.name||x.baseId||"").toLowerCase()).filter(Boolean);
  status.textContent=`Imported ${roster.length} roster units.`;
  show("dashboard");render();
 }catch(e){status.textContent="The frontend is ready, but the production Comlink backend still needs to be deployed. Use Demo for now.";}
};
document.getElementById("mode").onchange=render;render();
