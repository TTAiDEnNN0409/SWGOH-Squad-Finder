# SWGOH Squad Finder V2

V2 adds the real Ally Code import interface and the backend contract needed for Comlink.

Current package:
- Responsive dashboard
- Ally Code validation
- `/api/roster/:allyCode` integration point
- Normalized roster shape
- Squad scoring UI
- Demo fallback
- Backend contract notes

Important: the browser cannot magically reach a local Comlink service on a deployed website. A server must run Comlink and expose our backend endpoint. This package therefore includes the frontend and exact API contract, but does not pretend the live backend is deployed.

Recommended production stack:
Frontend: this static HTML/CSS/JS or React later
Backend: Node/Express or Python/FastAPI
Roster source: SWGOH Comlink
Database/cache: SQLite/PostgreSQL + short-lived roster cache
